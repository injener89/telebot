<?php
namespace core\models;

use CFormModel;

class UploadForm extends CFormModel
{
    public $file;

    public $maxSize;
    public $mimeTypes;
    public $types;

    public function rules()
    {
        return [
            ['file', 'file', 'maxSize' => $this->maxSize, 'mimeTypes' => $this->mimeTypes, 'types' => $this->types]
        ];
    }
}
