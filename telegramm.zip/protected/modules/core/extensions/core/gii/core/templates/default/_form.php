<?php
/**
 * The following variables are available in this template:
 * - $this: the BootCrudCode object
 *
 * @category CoreGiiTemplate
 * @package  core
 * @author   Core Team <team@websum.uz>
 * @license  https://github.com/core/core/blob/master/LICENSE BSD
 * @link     http://websum.uz
 */
?>
<?php
echo <<<EOF
<?php
/**
 * Отображение для _form:
 *
 *   @category CoreView
 *   @package  core
 *   @author   Core Team <team@websum.uz>
 *   @license  https://github.com/core/core/blob/master/LICENSE BSD
 *   @link     http://websum.uz
 *
 *   @var \$model {$this->modelClass}
 *   @var \$form TbActiveForm
 *   @var \$this {$this->controllerClass}
 **/
\$form = \$this->beginWidget(
    'bootstrap.widgets.TbActiveForm', array(
        'id'                     => '{$this->class2id($this->modelClass)}-form',
        'enableAjaxValidation'   => false,
        'enableClientValidation' => true,
        'htmlOptions'            => array('class' => 'well'),
    )
);
?>\n
EOF;
?>

<div class="alert alert-info">
    <?php echo "<?php echo Yii::t('{$this->mid}', 'Поля, отмеченные'); ?>\n"; ?>
    <span class="required">*</span>
    <?php echo "<?php echo Yii::t('{$this->mid}', 'обязательны.'); ?>\n"; ?>
</div>

<?php echo "<?php echo \$form->errorSummary(\$model); ?>\n"; ?>

<?php
foreach ($this->tableSchema->columns as $column) {
    if ($column->autoIncrement) {
        continue;
    }

    $activeRow = $this->generateActiveGroup($this->modelClass, $column);
    echo <<<EOF
    <div class="row">
        <div class="col-sm-7">
            <?php echo {$activeRow}; ?>
        </div>
    </div>\n
EOF;
}
?>

<?php
echo <<<EOF
    <?php
    \$this->widget(
        'bootstrap.widgets.TbButton', array(
            'buttonType' => 'submit',
            'context'    => 'primary',
            'label'      => Yii::t('{$this->mid}', 'Сохранить {$this->vin} и продолжить'),
        )
    ); ?>
    <?php
    \$this->widget(
        'bootstrap.widgets.TbButton', array(
            'buttonType' => 'submit',
            'htmlOptions'=> array('name' => 'submit-type', 'value' => 'index'),
            'label'      => Yii::t('{$this->mid}', 'Сохранить {$this->vin} и закрыть'),
        )
    ); ?>\n
EOF;
?>

<?php echo "<?php \$this->endWidget(); ?>"; ?>
