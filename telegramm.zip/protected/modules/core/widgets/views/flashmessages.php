<?php $this->widget('bootstrap.widgets.TbAlert', $options);
