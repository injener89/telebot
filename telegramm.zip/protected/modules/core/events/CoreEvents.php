<?php
namespace core\events;

class CoreEvents
{
    const BEFORE_BACKEND_CONTROLLER_ACTION = 'core.before.backend.controller.action';

    const BACKEND_CONTROLLER_INIT = 'core.backend.controller.init';

    const BEFORE_FRONT_CONTROLLER_INIT = 'core.before.front.controller.init';
}
