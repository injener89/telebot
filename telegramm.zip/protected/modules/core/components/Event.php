<?php
namespace core\components;

use Symfony\Component\EventDispatcher\Event as MainEvent;

class Event extends MainEvent
{

}
