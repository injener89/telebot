Наша команда
============

- Опейкин Андрей [http://amylabs.ru](http://amylabs.ru/)
- Тимашов Максим  apexwire@amylabs.ru
- Седов Николай [http://amylabs.ru](http://amylabs.ru)
- Кучеров Антон [http://idexter.ru/](http://idexter.ru/)
- Плаксунов Юрий [http://amylabs.ru](http://amylabs.ru)
- Чемезов Михаил [http://vk.com/m.chemezov](http://vk.com/m.chemezov)
- Филимонов Олег olegsabian@gmail.com

И еще порядка [70 контрибьюторов на Github](https://github.com/core/core/graphs/contributors)!

**[Ждем только тебя !](http://websum.uz/contacts)**
